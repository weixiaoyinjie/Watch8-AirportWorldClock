package com.airportworldclock;

import java.text.Normalizer;
import java.util.Locale;

/** One metropolitan area; airport codes are searchable aliases, not separate clocks. */
public final class AirportCity {
    public final String code;
    public final String chinese;
    public final String english;
    public final String country;
    public final String airports;
    public final String zoneId;
    public final String region;
    private final String searchKey;

    public AirportCity(String code, String chinese, String english, String country,
                       String airports, String zoneId, String region) {
        this.code = code;
        this.chinese = chinese;
        this.english = english;
        this.country = country;
        this.airports = airports;
        this.zoneId = zoneId;
        this.region = region;
        this.searchKey = normalized(chinese + " " + english + " " + country + " " + airports + " " + code + " " + region);
    }

    public boolean matches(String keyword) {
        return searchKey.contains(normalized(keyword));
    }

    private static String normalized(String s) {
        String n = Normalizer.normalize(s, Normalizer.Form.NFD);
        return n.replaceAll("\\p{M}+", "").toLowerCase(Locale.ROOT).trim();
    }
}
