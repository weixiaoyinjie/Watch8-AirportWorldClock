package com.airportworldclock;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Curated city/time-zone directory of major international airport metros.
 * IATA codes are searchable aliases; clocks follow IANA ZoneId, not fixed UTC offsets.
 * Airport listings are not live operational/status information.
 */
public final class AirportData {
    public static final List<AirportCity> ALL;
    public static final Map<String, AirportCity> BY_CODE;
    public static final String[] REGIONS = {"美洲", "欧洲", "中东", "亚洲", "大洋洲", "非洲"};
    public static final String DEFAULT_PINS = "EZE,JFK,LHR,CDG,DXB,DOH,SIN,HKG,PEK,PVG,HND,SYD";

    static {
        ArrayList<AirportCity> a = new ArrayList<>();
        // 美洲
        add(a,"EZE","布宜诺斯艾利斯","Buenos Aires","阿根廷","EZE / AEP","America/Argentina/Buenos_Aires","美洲");
        add(a,"SCL","圣地亚哥","Santiago","智利","SCL","America/Santiago","美洲");
        add(a,"MVD","蒙得维的亚","Montevideo","乌拉圭","MVD","America/Montevideo","美洲");
        add(a,"GRU","圣保罗","São Paulo","巴西","GRU / CGH","America/Sao_Paulo","美洲");
        add(a,"GIG","里约热内卢","Rio de Janeiro","巴西","GIG / SDU","America/Sao_Paulo","美洲");
        add(a,"LIM","利马","Lima","秘鲁","LIM","America/Lima","美洲");
        add(a,"BOG","波哥大","Bogotá","哥伦比亚","BOG","America/Bogota","美洲");
        add(a,"UIO","基多","Quito","厄瓜多尔","UIO","America/Guayaquil","美洲");
        add(a,"MEX","墨西哥城","Mexico City","墨西哥","MEX / NLU","America/Mexico_City","美洲");
        add(a,"GDL","瓜达拉哈拉","Guadalajara","墨西哥","GDL","America/Mexico_City","美洲");
        add(a,"CUN","坎昆","Cancún","墨西哥","CUN","America/Cancun","美洲");
        add(a,"PTY","巴拿马城","Panama City","巴拿马","PTY","America/Panama","美洲");
        add(a,"JFK","纽约","New York","美国","JFK / EWR / LGA","America/New_York","美洲");
        add(a,"BOS","波士顿","Boston","美国","BOS","America/New_York","美洲");
        add(a,"IAD","华盛顿","Washington DC","美国","IAD / DCA","America/New_York","美洲");
        add(a,"ORD","芝加哥","Chicago","美国","ORD / MDW","America/Chicago","美洲");
        add(a,"ATL","亚特兰大","Atlanta","美国","ATL","America/New_York","美洲");
        add(a,"MIA","迈阿密","Miami","美国","MIA","America/New_York","美洲");
        add(a,"MCO","奥兰多","Orlando","美国","MCO","America/New_York","美洲");
        add(a,"DFW","达拉斯","Dallas","美国","DFW / DAL","America/Chicago","美洲");
        add(a,"IAH","休斯敦","Houston","美国","IAH / HOU","America/Chicago","美洲");
        add(a,"DEN","丹佛","Denver","美国","DEN","America/Denver","美洲");
        add(a,"PHX","凤凰城","Phoenix","美国","PHX","America/Phoenix","美洲");
        add(a,"LAX","洛杉矶","Los Angeles","美国","LAX","America/Los_Angeles","美洲");
        add(a,"SFO","旧金山","San Francisco","美国","SFO","America/Los_Angeles","美洲");
        add(a,"SEA","西雅图","Seattle","美国","SEA","America/Los_Angeles","美洲");
        add(a,"LAS","拉斯维加斯","Las Vegas","美国","LAS","America/Los_Angeles","美洲");
        add(a,"YYZ","多伦多","Toronto","加拿大","YYZ / YTZ","America/Toronto","美洲");
        add(a,"YUL","蒙特利尔","Montréal","加拿大","YUL","America/Toronto","美洲");
        add(a,"YVR","温哥华","Vancouver","加拿大","YVR","America/Vancouver","美洲");
        add(a,"YYC","卡尔加里","Calgary","加拿大","YYC","America/Edmonton","美洲");

        // 欧洲
        add(a,"LHR","伦敦","London","英国","LHR / LGW / STN","Europe/London","欧洲");
        add(a,"CDG","巴黎","Paris","法国","CDG / ORY","Europe/Paris","欧洲");
        add(a,"AMS","阿姆斯特丹","Amsterdam","荷兰","AMS","Europe/Amsterdam","欧洲");
        add(a,"FRA","法兰克福","Frankfurt","德国","FRA","Europe/Berlin","欧洲");
        add(a,"MUC","慕尼黑","Munich","德国","MUC","Europe/Berlin","欧洲");
        add(a,"BER","柏林","Berlin","德国","BER","Europe/Berlin","欧洲");
        add(a,"MAD","马德里","Madrid","西班牙","MAD","Europe/Madrid","欧洲");
        add(a,"BCN","巴塞罗那","Barcelona","西班牙","BCN","Europe/Madrid","欧洲");
        add(a,"FCO","罗马","Rome","意大利","FCO / CIA","Europe/Rome","欧洲");
        add(a,"MXP","米兰","Milan","意大利","MXP / LIN","Europe/Rome","欧洲");
        add(a,"ZRH","苏黎世","Zurich","瑞士","ZRH","Europe/Zurich","欧洲");
        add(a,"GVA","日内瓦","Geneva","瑞士","GVA","Europe/Zurich","欧洲");
        add(a,"VIE","维也纳","Vienna","奥地利","VIE","Europe/Vienna","欧洲");
        add(a,"BRU","布鲁塞尔","Brussels","比利时","BRU","Europe/Brussels","欧洲");
        add(a,"DUB","都柏林","Dublin","爱尔兰","DUB","Europe/Dublin","欧洲");
        add(a,"LIS","里斯本","Lisbon","葡萄牙","LIS","Europe/Lisbon","欧洲");
        add(a,"OPO","波尔图","Porto","葡萄牙","OPO","Europe/Lisbon","欧洲");
        add(a,"CPH","哥本哈根","Copenhagen","丹麦","CPH","Europe/Copenhagen","欧洲");
        add(a,"ARN","斯德哥尔摩","Stockholm","瑞典","ARN","Europe/Stockholm","欧洲");
        add(a,"OSL","奥斯陆","Oslo","挪威","OSL","Europe/Oslo","欧洲");
        add(a,"HEL","赫尔辛基","Helsinki","芬兰","HEL","Europe/Helsinki","欧洲");
        add(a,"WAW","华沙","Warsaw","波兰","WAW","Europe/Warsaw","欧洲");
        add(a,"PRG","布拉格","Prague","捷克","PRG","Europe/Prague","欧洲");
        add(a,"BUD","布达佩斯","Budapest","匈牙利","BUD","Europe/Budapest","欧洲");
        add(a,"ATH","雅典","Athens","希腊","ATH","Europe/Athens","欧洲");
        add(a,"IST","伊斯坦布尔","Istanbul","土耳其","IST / SAW","Europe/Istanbul","欧洲");
        add(a,"SVO","莫斯科","Moscow","俄罗斯","SVO / DME / VKO","Europe/Moscow","欧洲");
        add(a,"LED","圣彼得堡","Saint Petersburg","俄罗斯","LED","Europe/Moscow","欧洲");
        add(a,"KEF","雷克雅未克","Reykjavík","冰岛","KEF","Atlantic/Reykjavik","欧洲");

        // 中东
        add(a,"DXB","迪拜","Dubai","阿联酋","DXB / DWC","Asia/Dubai","中东");
        add(a,"AUH","阿布扎比","Abu Dhabi","阿联酋","AUH","Asia/Dubai","中东");
        add(a,"DOH","多哈","Doha","卡塔尔","DOH","Asia/Qatar","中东");
        add(a,"RUH","利雅得","Riyadh","沙特阿拉伯","RUH","Asia/Riyadh","中东");
        add(a,"JED","吉达","Jeddah","沙特阿拉伯","JED","Asia/Riyadh","中东");
        add(a,"MCT","马斯喀特","Muscat","阿曼","MCT","Asia/Muscat","中东");
        add(a,"KWI","科威特城","Kuwait City","科威特","KWI","Asia/Kuwait","中东");
        add(a,"BAH","麦纳麦","Manama","巴林","BAH","Asia/Bahrain","中东");
        add(a,"TLV","特拉维夫","Tel Aviv","以色列","TLV","Asia/Jerusalem","中东");
        add(a,"AMM","安曼","Amman","约旦","AMM","Asia/Amman","中东");
        add(a,"IKA","德黑兰","Tehran","伊朗","IKA / THR","Asia/Tehran","中东");

        // 亚洲
        add(a,"PEK","北京","Beijing","中国","PEK / PKX","Asia/Shanghai","亚洲");
        add(a,"PVG","上海","Shanghai","中国","PVG / SHA","Asia/Shanghai","亚洲");
        add(a,"CAN","广州","Guangzhou","中国","CAN","Asia/Shanghai","亚洲");
        add(a,"SZX","深圳","Shenzhen","中国","SZX","Asia/Shanghai","亚洲");
        add(a,"TFU","成都","Chengdu","中国","TFU / CTU","Asia/Shanghai","亚洲");
        add(a,"CKG","重庆","Chongqing","中国","CKG","Asia/Shanghai","亚洲");
        add(a,"HGH","杭州","Hangzhou","中国","HGH","Asia/Shanghai","亚洲");
        add(a,"XIY","西安","Xi'an","中国","XIY","Asia/Shanghai","亚洲");
        add(a,"HKG","香港","Hong Kong","中国香港","HKG","Asia/Hong_Kong","亚洲");
        add(a,"MFM","澳门","Macau","中国澳门","MFM","Asia/Macau","亚洲");
        add(a,"TPE","台北","Taipei","中国台湾","TPE / TSA","Asia/Taipei","亚洲");
        add(a,"HND","东京","Tokyo","日本","HND / NRT","Asia/Tokyo","亚洲");
        add(a,"KIX","大阪","Osaka","日本","KIX / ITM","Asia/Tokyo","亚洲");
        add(a,"NGO","名古屋","Nagoya","日本","NGO","Asia/Tokyo","亚洲");
        add(a,"ICN","首尔","Seoul","韩国","ICN / GMP","Asia/Seoul","亚洲");
        add(a,"PUS","釜山","Busan","韩国","PUS","Asia/Seoul","亚洲");
        add(a,"SIN","新加坡","Singapore","新加坡","SIN","Asia/Singapore","亚洲");
        add(a,"KUL","吉隆坡","Kuala Lumpur","马来西亚","KUL","Asia/Kuala_Lumpur","亚洲");
        add(a,"BKK","曼谷","Bangkok","泰国","BKK / DMK","Asia/Bangkok","亚洲");
        add(a,"HKT","普吉岛","Phuket","泰国","HKT","Asia/Bangkok","亚洲");
        add(a,"HAN","河内","Hanoi","越南","HAN","Asia/Ho_Chi_Minh","亚洲");
        add(a,"SGN","胡志明市","Ho Chi Minh City","越南","SGN","Asia/Ho_Chi_Minh","亚洲");
        add(a,"CGK","雅加达","Jakarta","印度尼西亚","CGK","Asia/Jakarta","亚洲");
        add(a,"DPS","巴厘岛","Bali / Denpasar","印度尼西亚","DPS","Asia/Makassar","亚洲");
        add(a,"MNL","马尼拉","Manila","菲律宾","MNL","Asia/Manila","亚洲");
        add(a,"CEB","宿务","Cebu","菲律宾","CEB","Asia/Manila","亚洲");
        add(a,"DEL","新德里","New Delhi","印度","DEL","Asia/Kolkata","亚洲");
        add(a,"BOM","孟买","Mumbai","印度","BOM","Asia/Kolkata","亚洲");
        add(a,"BLR","班加罗尔","Bengaluru","印度","BLR","Asia/Kolkata","亚洲");
        add(a,"HYD","海得拉巴","Hyderabad","印度","HYD","Asia/Kolkata","亚洲");
        add(a,"KTM","加德满都","Kathmandu","尼泊尔","KTM","Asia/Kathmandu","亚洲");
        add(a,"DAC","达卡","Dhaka","孟加拉国","DAC","Asia/Dhaka","亚洲");
        add(a,"CMB","科伦坡","Colombo","斯里兰卡","CMB","Asia/Colombo","亚洲");
        add(a,"KHI","卡拉奇","Karachi","巴基斯坦","KHI","Asia/Karachi","亚洲");
        add(a,"LHE","拉合尔","Lahore","巴基斯坦","LHE","Asia/Karachi","亚洲");
        add(a,"TAS","塔什干","Tashkent","乌兹别克斯坦","TAS","Asia/Tashkent","亚洲");
        add(a,"ALA","阿拉木图","Almaty","哈萨克斯坦","ALA","Asia/Almaty","亚洲");
        add(a,"PNH","金边","Phnom Penh","柬埔寨","PNH","Asia/Phnom_Penh","亚洲");
        add(a,"RGN","仰光","Yangon","缅甸","RGN","Asia/Yangon","亚洲");

        // 大洋洲
        add(a,"SYD","悉尼","Sydney","澳大利亚","SYD","Australia/Sydney","大洋洲");
        add(a,"MEL","墨尔本","Melbourne","澳大利亚","MEL","Australia/Melbourne","大洋洲");
        add(a,"BNE","布里斯班","Brisbane","澳大利亚","BNE","Australia/Brisbane","大洋洲");
        add(a,"PER","珀斯","Perth","澳大利亚","PER","Australia/Perth","大洋洲");
        add(a,"ADL","阿德莱德","Adelaide","澳大利亚","ADL","Australia/Adelaide","大洋洲");
        add(a,"AKL","奥克兰","Auckland","新西兰","AKL","Pacific/Auckland","大洋洲");
        add(a,"WLG","惠灵顿","Wellington","新西兰","WLG","Pacific/Auckland","大洋洲");
        add(a,"CHC","基督城","Christchurch","新西兰","CHC","Pacific/Auckland","大洋洲");
        add(a,"NAN","楠迪","Nadi","斐济","NAN","Pacific/Fiji","大洋洲");

        // 非洲
        add(a,"JNB","约翰内斯堡","Johannesburg","南非","JNB","Africa/Johannesburg","非洲");
        add(a,"CPT","开普敦","Cape Town","南非","CPT","Africa/Johannesburg","非洲");
        add(a,"NBO","内罗毕","Nairobi","肯尼亚","NBO","Africa/Nairobi","非洲");
        add(a,"CAI","开罗","Cairo","埃及","CAI","Africa/Cairo","非洲");
        add(a,"ADD","亚的斯亚贝巴","Addis Ababa","埃塞俄比亚","ADD","Africa/Addis_Ababa","非洲");
        add(a,"CMN","卡萨布兰卡","Casablanca","摩洛哥","CMN","Africa/Casablanca","非洲");
        add(a,"RAK","马拉喀什","Marrakesh","摩洛哥","RAK","Africa/Casablanca","非洲");
        add(a,"LOS","拉各斯","Lagos","尼日利亚","LOS","Africa/Lagos","非洲");
        add(a,"ACC","阿克拉","Accra","加纳","ACC","Africa/Accra","非洲");
        add(a,"TUN","突尼斯市","Tunis","突尼斯","TUN","Africa/Tunis","非洲");
        add(a,"ALG","阿尔及尔","Algiers","阿尔及利亚","ALG","Africa/Algiers","非洲");
        add(a,"DAR","达累斯萨拉姆","Dar es Salaam","坦桑尼亚","DAR","Africa/Dar_es_Salaam","非洲");
        add(a,"MRU","路易港","Port Louis","毛里求斯","MRU","Indian/Mauritius","非洲");
        add(a,"SEZ","维多利亚","Victoria / Seychelles","塞舌尔","SEZ","Indian/Mahe","非洲");
        add(a,"DSS","达喀尔","Dakar","塞内加尔","DSS","Africa/Dakar","非洲");
        ALL = Collections.unmodifiableList(a);
        LinkedHashMap<String,AirportCity> codes = new LinkedHashMap<>();
        for (AirportCity c : a) {
            if (codes.containsKey(c.code)) throw new IllegalStateException("Duplicate: " + c.code);
            codes.put(c.code,c);
        }
        BY_CODE = Collections.unmodifiableMap(codes);
    }

    private AirportData() {}

    private static void add(List<AirportCity> list, String code, String chinese, String english,
                            String country, String airports, String zone, String region) {
        list.add(new AirportCity(code,chinese,english,country,airports,zone,region));
    }
}
