# No third-party libraries or reflection-dependent model classes.
