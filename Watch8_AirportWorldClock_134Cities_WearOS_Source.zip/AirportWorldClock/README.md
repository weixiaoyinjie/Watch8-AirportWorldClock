# Galaxy Watch8 世界机场时间（Wear OS 独立版）

本项目根据用户上传的 `AirportWorldClock_Android_Source_134Cities.zip` 改造；复用原来的 `AirportCity.java`、`AirportData.java` 数据结构、IANA 时区算法、网络校时接口，重做适合 Watch8 圆形屏幕的 `MainActivity.java`。

## 功能保持

- **134 座机场城市**：原城市目录、IATA 三字代码及多机场别名、城市的中文/英文名称和国家检索；六大区域与原排序保持一致。
- **常用收藏**：默认 12 座城市，可通过 ★ / ☆ 收藏或移除。
- **参考城市**：点击首页参考城市进入收藏城市列表切换，或长按某张城市卡片设为参考。
- **实时世界时间**：12/24 小时、日期及中文星期、相对参考城市的昨天/明天标志、UTC 时差、相对时差与昼夜标签。
- **详情**：秒数、IANA 时区、全部机场代码及夏令时状态，可直接设为参考城市或收藏。
- **网络校时**：启动时请求一次 `https://gateway.timeapi.world/timezone/Etc/UTC`；设置页可以手动重试。失败回退设备时钟；不修改手表系统时间。
- **轻量省电**：纯黑 AMOLED、无持续网络轮询、后台停止刷新、只在前台按分钟更新、无第三方 SDK、无定位/健康权限。

## Watch8 操作

1. 打开：先看参考城市与常用世界时间。向上滑动查看更多。
2. 点击 `★ 常用` / `全部`：切换收藏和 134 座完整目录。全部目录按六大区域排列。
3. 点击 `⌕`：通过手表键盘输入机场代码（如 `JFK`、`PVG`）或城市中英文名搜索。
4. 点击城市卡片：查看详细时间 / 夏令时 / UTC / 机场别名；长按卡片快速设为参考城市。
5. 点击 `☆` / `★`：收藏或移除。点击参考城市：从常用列表中切换。
6. 点击右上角 `⚙`：切换 12/24 小时、联网校时、选择参考城市。
7. 支持手指纵向滚动，以及 Wear OS 可分发的旋转输入事件（实际表冠行为取决于设备映射）。

## 适配说明

- `android.hardware.type.watch` 为必需，标记 `com.google.android.wearable.standalone=true`，手表可以独立运行。
- 按圆形屏幕增加顶部/两侧/底部安全留白，单列宽卡、扩大触控区域，缩窄时自动调整数字字号；同样兼容 40mm 圆屏。
- 使用纯 Android SDK 组件，不依赖 Wear Compose 或三方 UI；简单、体积小。
- 包名 `com.airportworldclock.watch`，与原手机 App 的包名 `com.airportworldclock` 区分，**无需手机 App、不会自动同步原手机收藏**。
- Android `minSdk 26`、`targetSdk 35`，Gradle 8.11.1、AGP 8.9.2、Java 17。

## 在 GitHub Actions 生成 APK（本 ZIP 为源码工程，不是 APK）

1. 在 https://github.com/new 新建仓库（可设为 Private）。
2. 解压本 ZIP，将 `AirportWorldClock` 目录中的**所有内容**上传到仓库根目录；尤其要包含 `.github/workflows/build-apk.yml` 隐藏目录，不要多套一层文件夹。进入 `Add file` → `Upload files` 上传并提交。
3. 转到 `Actions` → **构建 Watch8 世界时间 APK** → `Run workflow`（上传至 main 或 master 也会触发）。
4. 构建成功后，在最新的 workflow 页面底部的 `Artifacts` 下载 **Watch8-AirportWorldClock-APK**。
5. 解压 Artifact 得到 `app-debug.apk`。使用 Wear Installer 2 或 ADB 无线调试安装到 Galaxy Watch8。此 APK 是调试签名版，适合自用。

也可在具有 Android SDK 35 和 Gradle 8.11.1 的电脑上执行：

```bash
gradle --no-daemon :app:assembleDebug
```

输出路径：`app/build/outputs/apk/debug/app-debug.apk`。

## 限制

- 本项目保留原 API 服务地址，其第三方服务的可用性没有保证；若接口失效，世界时间继续依赖手表系统时间运行。
- 不提供航班状态或机场实时航班信息。
- 项目自带 GitHub Actions 自动编译配置；交付的源代码包在本地环境中未经过真实 Android SDK 编译或 Watch8 真机安装测试。
